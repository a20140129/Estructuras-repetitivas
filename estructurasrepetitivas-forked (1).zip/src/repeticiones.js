console.log("Ciclo del 1 al 10");
for (let i = 1; i <= 10; i++) {
  console.log("Vuelta N° " + i);
}
console.log("Fin del ciclo");
